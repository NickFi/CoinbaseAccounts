﻿// This application is based on https://github.com/iYalovoy/demibyte.coinbase

using System;
using System.Text;
using System.Security.Cryptography;
using Flurl;
using Flurl.Http;
using Newtonsoft.Json;
using System.Linq;

namespace coin_base
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			var host = "https://api.coinbase.com/";
			var apiKey = "Enter your key here";
			var apiSecret = "Enter your secret here";
			
			var unixTimestamp = (Int32)(DateTime.UtcNow.Subtract (new DateTime (1970, 1, 1))).TotalSeconds;
			var apiVersion = "2018-01-13";  // check value from https://www.coinbase.com/settings/api - it is the build date of Coinbase API (not our Application!) 
//			var message = string.Format ("{0}GET/v2/prices/spot?currency={1}", unixTimestamp.ToString (), currency);
		    var message = string.Format ("{0}GET/v2/prices", unixTimestamp.ToString ());
		    
		    // http://api.coinbase.com/v2/prices/ETH-USD/spot // without colon before ETH-USD!!!
		    // https://api.coinbase.com/v2/prices/ETH-USD/spot

			byte[] secretKey = Encoding.UTF8.GetBytes (apiSecret);
			HMACSHA256 hmac = new HMACSHA256 (secretKey);
			
			hmac.Initialize ();
			byte[] bytes = Encoding.UTF8.GetBytes (message);
			byte[] rawHmac = hmac.ComputeHash (bytes);
			var signature = rawHmac.ByteArrayToHexString ();

			var jsonCodeBTC = host
			    .AppendPathSegment ("v2/prices/BTC-AUD/spot")
			    .WithHeader ("CB-VERSION", apiVersion)                                          
				.WithHeader ("CB-ACCESS-SIGN", signature)
				.WithHeader ("CB-ACCESS-TIMESTAMP", unixTimestamp)
				.WithHeader ("CB-ACCESS-KEY", apiKey)
				.GetJsonAsync<dynamic> ()
				.Result;

//			Console.WriteLine (price1.ToString (Formatting.None));
            dynamic stuff = null;
            try {
                stuff = JsonConvert.DeserializeObject(jsonCodeBTC.ToString (Formatting.None));
            }
            catch(Exception) {
                Console.Write("Error deserializing");
            }
            
//            string baseCurr = stuff.data.base;
            string exchange = stuff.data.amount;
            string curr = stuff.data.currency;
            double fBTCExchangeRate = Convert.ToDouble(exchange);
			
            Console.WriteLine("BTC: " + curr + " " + exchange);
//			Console.WriteLine();

			var jsonCodeETH = host
//				.AppendPathSegment ("v2/prices/spot")
			    .AppendPathSegment ("v2/prices/ETH-AUD/spot")
			    .WithHeader ("CB-VERSION", apiVersion)                                          
//				.SetQueryParam ("currency", currency)
				.WithHeader ("CB-ACCESS-SIGN", signature)
				.WithHeader ("CB-ACCESS-TIMESTAMP", unixTimestamp)
				.WithHeader ("CB-ACCESS-KEY", apiKey)
				.GetJsonAsync<dynamic> ()
				.Result;

//			Console.WriteLine (price2.ToString (Formatting.None));
            stuff = null;
            try {
                stuff = JsonConvert.DeserializeObject(jsonCodeETH.ToString (Formatting.None));
            }
            catch(Exception) {
                Console.Write("Error deserializing");
            }
            
//            baseCurr = stuff.data.base;
            exchange = stuff.data.amount;
            curr = stuff.data.currency;
            double fETHExchangeRate = Convert.ToDouble(exchange);
			
            Console.WriteLine("ETH: " + curr + " " + exchange);

//			Console.WriteLine();
			
			var jsonCodeLTC = host
//				.AppendPathSegment ("v2/prices/spot")
			    .AppendPathSegment ("v2/prices/LTC-AUD/spot")
			    .WithHeader ("CB-VERSION", apiVersion)                                          
//				.SetQueryParam ("currency", currency)
				.WithHeader ("CB-ACCESS-SIGN", signature)
				.WithHeader ("CB-ACCESS-TIMESTAMP", unixTimestamp)
				.WithHeader ("CB-ACCESS-KEY", apiKey)
				.GetJsonAsync<dynamic> ()
				.Result;

//			Console.WriteLine (price3.ToString (Formatting.None));
            stuff = null;
            try {
                stuff = JsonConvert.DeserializeObject(jsonCodeLTC.ToString (Formatting.None));
            }
            catch(Exception) {
                Console.Write("Error deserializing");
            }
            
//            baseCurr = stuff.data.base;
            exchange = stuff.data.amount;
            curr = stuff.data.currency;
            double fLTCExchangeRate = Convert.ToDouble(exchange);
			
            Console.WriteLine("LTC: " + curr + " " + exchange);
			Console.WriteLine();
			
//			Console.ReadLine();
			
//			return;
			
			message = string.Format ("{0}GET/v2/accounts", unixTimestamp.ToString ());

			bytes = Encoding.UTF8.GetBytes (message);
			rawHmac = hmac.ComputeHash (bytes);
			signature = rawHmac.ByteArrayToHexString ();
			
			var jsonCode = host
				.AppendPathSegment ("v2/accounts")
				.WithHeader ("CB-ACCESS-SIGN", signature)
				.WithHeader ("CB-ACCESS-TIMESTAMP", unixTimestamp)
				.WithHeader ("CB-ACCESS-KEY", apiKey)
			    .WithHeader ("CB-VERSION", apiVersion)
				.GetJsonAsync<dynamic> ()
				.Result;

//			Console.WriteLine (jsonCode.ToString (Formatting.None));
//			Console.ReadLine ();
			
            stuff = null;
            try {
                stuff = JsonConvert.DeserializeObject(jsonCode.ToString (Formatting.None));
            }
            catch(Exception) {
                Console.Write("Error deserializing");
            }
            
            int count = stuff.data.Count;
            double[] fAmount = new double[5];
            
            for(int i = 0; i < count; i++) {
                string currAmount = stuff.data[i].balance.amount;
                string currCode = stuff.data[i].balance.currency;
                fAmount[i] = Convert.ToDouble(currAmount);
                
                Console.WriteLine(currCode + ": " + currAmount);
            }
            
            double fTotal = fBTCExchangeRate * fAmount[4] + fETHExchangeRate * fAmount[2] + fLTCExchangeRate * fAmount[1];
            Console.WriteLine();
            Console.WriteLine("Total: AUD " + string.Format("{0:0.00}", fTotal));
            
            Console.ReadLine ();
		}
	}
}
